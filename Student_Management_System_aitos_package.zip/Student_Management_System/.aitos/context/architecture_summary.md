# Architecture Summary

Target Stack: LARAVEL 11
Entity counts: 6 models mapped.