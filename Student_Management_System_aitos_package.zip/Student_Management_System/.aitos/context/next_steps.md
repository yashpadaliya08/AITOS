# Next Steps

1. Complete active models scaffolding.
2. Bind API routing definitions.