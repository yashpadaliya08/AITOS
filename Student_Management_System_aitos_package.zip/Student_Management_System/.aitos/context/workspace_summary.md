# Workspace Summary

Active developer environment for project Student Management System.
Framework: LARAVEL 11