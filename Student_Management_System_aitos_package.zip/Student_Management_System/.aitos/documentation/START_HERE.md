# Start Here Guide

Welcome to Student Management System starter package.

- Project Goal: Hackathon
- Stack: 

Review database schema under .aitos/data/database_schema.json.