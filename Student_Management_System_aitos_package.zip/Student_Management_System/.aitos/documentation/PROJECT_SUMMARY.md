# Project Summary

Hackathon

## Target Modules
- Authentication Module: Handles user login, logout, and session management for Administrator, Faculty, and Student roles.
- User Management Module: Allows administrators to create, read, update, and delete user accounts and assign roles.
- Student Management Module: Enables administrators to add, edit, delete, and search student records. Allows students to view their profile.
- Course Management Module: Facilitates administrators in managing course details, including creation, modification, and deletion. Allows students to view enrolled courses.
- Department Management Module: Provides administrators with functionalities to manage department information.
- Faculty Management Module: Allows administrators to manage faculty member details.
- Grade Management Module: Enables faculty members to input and update grades for courses they teach.
- Reporting Module: Generates reports such as department-wise student counts and course enrollment lists.