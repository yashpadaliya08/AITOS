# API Specifications Guide

### Resource: studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess

- **GET /api/studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess**
  *Description*: Retrieve list of all studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess
- **POST /api/studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess**
  *Description*: Create a new studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycourse record
  *Validation Rules*:
    - `email`: `required|string|max:255`
    - `name`: `required|string|max:255`
- **GET /api/studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess/{id}**
  *Description*: Retrieve details for a single studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycourse
- **PUT /api/studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess/{id}**
  *Description*: Update attributes of a single studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycourse
  *Validation Rules*:
    - `email`: `nullable|string|max:255`
    - `name`: `nullable|string|max:255`
- **DELETE /api/studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess/{id}**
  *Description*: Hard delete a single studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycourse record

### Resource: departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess

- **GET /api/departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess**
  *Description*: Retrieve list of all departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess
- **POST /api/departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess**
  *Description*: Create a new departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycourse record
  *Validation Rules*:
    - `name`: `required|string|max:255`
    - `studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycourse_id`: `required|integer`
- **GET /api/departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess/{id}**
  *Description*: Retrieve details for a single departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycourse
- **PUT /api/departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess/{id}**
  *Description*: Update attributes of a single departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycourse
  *Validation Rules*:
    - `name`: `nullable|string|max:255`
    - `studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycourse_id`: `nullable|integer`
- **DELETE /api/departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess/{id}**
  *Description*: Hard delete a single departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycourse record

### Resource: courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss

- **GET /api/courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss**
  *Description*: Retrieve list of all courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss
- **POST /api/courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss**
  *Description*: Create a new courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudent record
  *Validation Rules*:
    - `name`: `required|string|max:255`
    - `description`: `required|string`
- **GET /api/courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss/{id}**
  *Description*: Retrieve details for a single courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudent
- **PUT /api/courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss/{id}**
  *Description*: Update attributes of a single courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudent
  *Validation Rules*:
    - `name`: `nullable|string|max:255`
    - `description`: `nullable|string`
- **DELETE /api/courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss/{id}**
  *Description*: Hard delete a single courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudent record

### Resource: facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess

- **GET /api/facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess**
  *Description*: Retrieve list of all facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess
- **POST /api/facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess**
  *Description*: Create a new facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycourse record
  *Validation Rules*:
    - `email`: `required|string|max:255`
    - `name`: `required|string|max:255`
- **GET /api/facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess/{id}**
  *Description*: Retrieve details for a single facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycourse
- **PUT /api/facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess/{id}**
  *Description*: Update attributes of a single facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycourse
  *Validation Rules*:
    - `email`: `nullable|string|max:255`
    - `name`: `nullable|string|max:255`
- **DELETE /api/facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess/{id}**
  *Description*: Hard delete a single facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycourse record

### Resource: enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses

- **GET /api/enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses**
  *Description*: Retrieve list of all enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses
- **POST /api/enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses**
  *Description*: Create a new enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourse record
- **GET /api/enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses/{id}**
  *Description*: Retrieve details for a single enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourse
- **PUT /api/enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses/{id}**
  *Description*: Update attributes of a single enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourse
- **DELETE /api/enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses/{id}**
  *Description*: Hard delete a single enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourse record

### Resource: userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles

- **GET /api/userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles**
  *Description*: Retrieve list of all userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles
- **POST /api/userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles**
  *Description*: Create a new userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonrole record
  *Validation Rules*:
    - `email`: `required|string|max:255`
    - `password`: `required|string|max:255`
- **GET /api/userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles/{id}**
  *Description*: Retrieve details for a single userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonrole
- **PUT /api/userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles/{id}**
  *Description*: Update attributes of a single userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonrole
  *Validation Rules*:
    - `email`: `nullable|string|max:255`
    - `password`: `nullable|string|max:255`
- **DELETE /api/userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles/{id}**
  *Description*: Hard delete a single userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonrole record

