# Database Schema Guide

### Table: studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess

| Column | Type | Attributes |
| --- | --- | --- |
| id | INTEGER | PK, AI |
| email | VARCHAR(255) | Unique |
| name | VARCHAR(255) |  |

### Table: departmentattributesincludedepartmentidnameheadofdepartmentrelationshipshasmanystudentshasmanycoursess

| Column | Type | Attributes |
| --- | --- | --- |
| id | INTEGER | PK, AI |
| name | VARCHAR(255) |  |
| studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycourse_id | INTEGER | FK -> studentattributesincludestudentidnameemaildateofbirthdepartmentidrelationshipsbelongstoonedepartmentenrollsinmanycoursess |

### Table: courseattributesincludecourseidnamedescriptiondepartmentidrelationshipsbelongstoonedepartmenttaughtbymanyfacultyenrolledbymanystudentss

| Column | Type | Attributes |
| --- | --- | --- |
| id | INTEGER | PK, AI |
| name | VARCHAR(255) |  |
| description | TEXT |  |

### Table: facultyattributesincludefacultyidnameemaildepartmentidrelationshipsbelongstoonedepartmentteachesmanycoursess

| Column | Type | Attributes |
| --- | --- | --- |
| id | INTEGER | PK, AI |
| email | VARCHAR(255) | Unique |
| name | VARCHAR(255) |  |

### Table: enrollmentattributesincludeenrollmentidstudentidcourseidenrollmentdategraderelationshipslinksstudenttocourses

| Column | Type | Attributes |
| --- | --- | --- |
| id | INTEGER | PK, AI |

### Table: userattributesincludeuseridemailpasswordrolerelationshipslinkstostudentfacultyoradministratorbasedonroles

| Column | Type | Attributes |
| --- | --- | --- |
| id | INTEGER | PK, AI |
| email | VARCHAR(255) | Unique |
| password | VARCHAR(255) |  |

