# Student Management System

test

## Get Started
Read START_HERE.md to launch development sprints.