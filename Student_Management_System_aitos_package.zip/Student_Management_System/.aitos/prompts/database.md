=== Database DEVELOPMENT PROMPT PACK ===

You are implementing the Database layer for project: **Student Management System**.
Target Framework: LARAVEL 11
Target Database: SQLITE
Target Frontend: BLADE TEMPLATES + BOOTSTRAP 5

## Active Scope Instructions
Write physical migrations scripts, key relations definitions, index optimizations, and SQL seed files.

## Global Business & Architectural Rules
Only Administrators can perform CRUD operations on master data (Students, Courses, Departments, Faculty).
Each Student must belong to exactly one Department.
A Student can enroll in multiple Courses.
A Faculty member can teach multiple Courses.
Faculty members can only manage grades for courses they are assigned to teach.
Students can only view their own academic information and enrolled courses.
All users must be authenticated to access system functionalities.

## Target Blueprints
- Business: ## Business Blueprint: Student Management System

### 1. Target Audience

*   **Primary Users:**
    *   **College Administrators:** Staff responsible...
- Technical: ## Technical Blueprint: Student Management System

### 1. Core Frameworks Structure

This system will adopt a modern, full-stack architecture, emphasi...

## Next Steps
1. Load CURRENT_CONTEXT.md from the repository workspace.
2. Align code naming styles to code_generation_model.json mappings.
3. Perform unit/integration validations matching testing.md guidelines.